#include "ebuImage.h"

int averageBlockValues(ebuImage*, ebuImage*);