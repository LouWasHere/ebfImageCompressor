#include "ebfImage.h"
#include "ebuImage.h"

int compareEbf(ebfImage*, ebfImage*);
int freeAndReturn(ebfImage*, ebfImage*);
int compareEbu(ebuImage*, ebuImage*);
int freeAndReturnEbu(ebuImage*, ebuImage*);